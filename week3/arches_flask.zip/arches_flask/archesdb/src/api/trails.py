from flask import Blueprint

bp = Blueprint('trails', __name__, url_prefix='/trails')
