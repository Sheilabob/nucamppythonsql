from flask import Blueprint

bp = Blueprint('pictures', __name__, url_prefix='/pictures')
