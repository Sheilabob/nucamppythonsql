from flask import Blueprint

bp = Blueprint('maps', __name__, url_prefix='/maps')
