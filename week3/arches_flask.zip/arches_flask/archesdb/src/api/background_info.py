from flask import Blueprint

bp = Blueprint('background_info', __name__, url_prefix='/background_info')
