from flask import Blueprint

bp = Blueprint('arches', __name__, url_prefix='/arches')
